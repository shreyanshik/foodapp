# FOOD-APP
This is the final project of my training that i took from Internshala.This is basically a food app which is created by me by  taking some help from Internshala tuitior.
This app is made from Kotlin.
Some features of this app are-
*It has favourite option.
*It has menubar.
*it has login and logout option.
